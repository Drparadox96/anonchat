require "sinatra"

get "/" do
  erb :index
end

post "/submit" do
  confession = params[:confession]
  erb :thanks, locals: { confession: confession }
end
